/*!
 * Copyright 2021-2021 Bosch Automotive Service Solutions Limited
 * All rights reserved.
 */
const path = require("path");
const { merge } = require("webpack-merge");
const { main, documentViewer, newHtmlWebpackPlugin } = require("./webpack.common.cjs");
const quick = process.env.QUICK === "true";
const WebpackShellPluginNext = require("webpack-shell-plugin-next");
module.exports = [
    merge(main, {
        mode: "development",
        entry: {
            main: path.resolve(__dirname, "src/angularjs/main/index.ts"),
            "service-worker": require.resolve("adt-gxm-web-ui-service-worker/service-worker")
        },
        devtool: "source-map",
        devServer: {
            static: [
                {
                    directory: path.resolve(__dirname, "static"),
                    publicPath: "/"
                },
                {
                    directory: path.resolve(__dirname, "static"),
                    publicPath: "/document-viewer/"
                },
                ...(quick ? [] : [
                    {
                        directory: path.resolve(__dirname, "node_modules"),
                        publicPath: "/node_modules/"
                    },
                    {
                        directory: path.resolve(__dirname, "node_modules"),
                        publicPath: "/document-viewer/node_modules/"
                    }
                ])
            ],
            client: { overlay: { errors: false, warnings: false } },
            hot: false,
            compress: false,
            port: 9000,
            headers: { "Access-Control-Allow-Origin": "*" },
            proxy: [
                {
                    context: ["/rest/vehicleContextVariables", "/i18n/adtr/locale-en.json"],
                    target: "http://localhost:5000",
                    secure: false,
                    changeOrigin: true
                },
                {
                    context: ["/rest"],
                    //target: "https://rdtdev1.rdt-dev.rdt.grade-x.com",
                    target: "https://rdtunstable.rdt-dev.rdt.grade-x.com",  
                    //target: "https://rdtpatchunstable2.rdt-dev.rdt.grade-x.com/",     
                    //target: "https://adt-uat.diag.alliance-rnm.com",    
                    //target: "https://rdttesting.rdt-dev.rdt.grade-x.com",         
                    secure: false,
                    changeOrigin: true
                }
            ]
        },
        plugins: [
            newHtmlWebpackPlugin({
                template: path.resolve(__dirname, "src/angularjs/main/index.html"),
                filename: "index.html", appName: "adtApplication", chunks: ["main"]
            }),
            new WebpackShellPluginNext({
                onAfterDone: {
                    scripts: [
                        "copyfiles -u 1 \"./static/**/*\" \"./public/www/\"",
                        "copyfiles -u 2 \"./.built/main/**/*\" \"./public/www/\""
                    ],
                    blocking: true,
                    parallel: false
                },
                safe: true
            })
        ]
    }),
    merge(documentViewer, {
        mode: "development",
        devtool: "source-map"
    })
];